package co.edu.poli.controlador;

import co.edu.poli.vista.MenuPrincipal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class setLogin {
    
    public void validarUsuario(JTextField usuario,JPasswordField contrasena){
      
        try {
            ResultSet rs;
            PreparedStatement ps;
            
            conexion objetoconexion=new conexion();
            
            String consulta="SELECT * FROM Usuario WHERE ingresoUsuario=? AND ingresoContrasena=?";
            
            ps=objetoconexion.establecerConexion().prepareStatement(consulta);
          
            String contra= String.valueOf(contrasena.getPassword());
            
            ps.setString(1, usuario.getText());
            ps.setString(2, contra);
          
            rs=ps.executeQuery();
            
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Usuario correcto");
                MenuPrincipal objetoMenu= new MenuPrincipal();
                objetoMenu.setVisible(true);
            }
            else{
                JOptionPane.showMessageDialog(null, "Usuario incorrecto");
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: "+e.toString());
        }
    }
}