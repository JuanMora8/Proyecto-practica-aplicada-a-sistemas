package co.edu.poli.controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class conexion {
    
    Connection conectar;
    String usuario="root";
    String contrasena="root";
    String bd="login";
    String ip="localhost";
    String puerto="3306";
    
    String cadena="jdbc:mysql://"+ip+":"+puerto+"/"+bd+
    "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    
    public Connection establecerConexion(){
        
        try {
            conectar = DriverManager.getConnection(cadena, usuario, contrasena);
            System.out.println("Conexión exitosa");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, 
            "Problemas en la conexión: " + e.toString());
        }
        
        return conectar;
    }
}