/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package co.edu.poli.vista;

import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class Login {

    public static void main(String[] args) {
     formLogin objetoLogin=new formLogin();
     objetoLogin.setVisible(true);
        
        
        
        
        
    }
}
