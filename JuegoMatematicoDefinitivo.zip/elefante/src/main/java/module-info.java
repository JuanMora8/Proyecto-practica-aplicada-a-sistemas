module com.mycompany.elefante {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
  requires java.sql;
    opens co.edu.poli.controlador to javafx.fxml;
    exports co.edu.poli.controlador;
}
