package co.edu.poli.modelo;

public class Nivel2 extends Nivel {

    public Nivel2() {
        super();
    }

    public Nivel2(int idNivel, String nombre, String regla) {
        super(idNivel, nombre, regla);
    }

    public boolean verificarReglaIntermedia() {
        return true;
    }

    @Override
    public int aplicarRegla(int n) {
        return n * 2; // ejemplo intermedio
    }
}