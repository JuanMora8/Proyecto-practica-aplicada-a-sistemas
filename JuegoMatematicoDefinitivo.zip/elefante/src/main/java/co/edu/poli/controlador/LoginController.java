package co.edu.poli.controlador;

import co.edu.poli.servicios.UsuarioDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.Node;
import javafx.stage.Stage;

import co.edu.poli.modelo.Usuario;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField txtCorreo;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private Label lblMensaje;

    // 🔥 INICIAR SESIÓN
    @FXML
    private void iniciarSesion(ActionEvent event) {

        String correo = txtCorreo.getText();
        String password = txtPassword.getText();

        // VALIDACIONES
        if (correo.isEmpty() || password.isEmpty()) {
            lblMensaje.setText("Todos los campos son obligatorios");
            return;
        }

        UsuarioDAO dao = new UsuarioDAO();

        // 🔥 AQUÍ ESTABA TU ERROR (ya corregido)
        Usuario usuario = dao.login(correo, password);

        if (usuario != null) {

            lblMensaje.setText("✅ Bienvenido " + usuario.getNombre());

            try {
                FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/co/edu/poli/vista/Nivel.fxml")
                );

                Parent root = loader.load();

                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }

        } else {
            lblMensaje.setText("❌ Usuario o contraseña incorrectos");
        }
    }

    // 🔥 IR A REGISTRO
    @FXML
   
private void irRegistro(ActionEvent event) {

    try {
        FXMLLoader loader = new FXMLLoader(
            getClass().getResource("/co/edu/poli/vista/Registro.fxml")
        );

        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    } catch (IOException e) {
        e.printStackTrace();
    }
}
}
