package co.edu.poli.modelo;

public class Nivel1 extends Nivel {

    public Nivel1() {
        super();
    }

    public Nivel1(int idNivel, String nombre, String regla) {
        super(idNivel, nombre, regla);
    }

    public boolean verificarReglaFacil() {
        return true;
    }

    @Override
    public int aplicarRegla(int n) {
        return n + 1; // ejemplo fácil
    }
}
