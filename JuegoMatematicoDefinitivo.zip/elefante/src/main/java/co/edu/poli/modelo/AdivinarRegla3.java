package co.edu.poli.modelo;

public class AdivinarRegla3 {

    private String descripcion;
    private String[] opciones = new String[3];
    private int indiceCorrecto;

    public AdivinarRegla3() {
    }

    public AdivinarRegla3(String descripcion, String[] opciones, int indiceCorrecto) {
        this.descripcion = descripcion;
        this.opciones = opciones;
        this.indiceCorrecto = indiceCorrecto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String[] getOpciones() {
        return opciones;
    }

    public void setOpciones(String[] opciones) {
        this.opciones = opciones;
    }

    public int getIndiceCorrecto() {
        return indiceCorrecto;
    }

    public void setIndiceCorrecto(int indiceCorrecto) {
        this.indiceCorrecto = indiceCorrecto;
    }

    public void seleccionarOpcion(int indice) {
        this.indiceCorrecto = indice;
    }

    public boolean esCorrecto() {
        return indiceCorrecto == 2;
    }
}
