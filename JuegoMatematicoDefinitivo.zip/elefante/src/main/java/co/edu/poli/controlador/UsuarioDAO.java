package co.edu.poli.controlador;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import co.edu.poli.modelo.Usuario;

public class UsuarioDAO {

    // =========================
    // 🔥 REGISTRAR USUARIO
    // =========================
    public boolean registrarUsuario(Usuario usuario) {

        String sql = "INSERT INTO usuario (nombre, correo, contrasena) VALUES (?, ?, ?)";

        Connection con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ No hay conexión a la base de datos");
            return false;
        }

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getContrasena());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                System.out.println("✅ Usuario registrado correctamente");
                return true;
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al registrar usuario:");
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println("❌ Error cerrando conexión");
            }
        }

        return false;
    }

    // =========================
    // 🔥 LOGIN USUARIO
    // =========================
    public Usuario login(String correo, String contrasena) {

        String sql = "SELECT * FROM usuario WHERE correo = ? AND contrasena = ?";

        Connection con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ No hay conexión a la base de datos");
            return null;
        }

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, correo);
            ps.setString(2, contrasena);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("✅ Login exitoso");

                return new Usuario(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("correo"),
                        rs.getString("contrasena")
                );
            }

        } catch (SQLException e) {
            System.out.println("❌ Error en login:");
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println("❌ Error cerrando conexión");
            }
        }

        System.out.println("❌ Usuario no encontrado");
        return null;
    }
}