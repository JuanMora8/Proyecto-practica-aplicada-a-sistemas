package co.edu.poli.modelo;

public class Nivel3 extends Nivel {

    public Nivel3() {
        super();
    }

    public Nivel3(int idNivel, String nombre, String regla) {
        super(idNivel, nombre, regla);
    }

    public boolean verificarReglaDificil() {
        return true;
    }

    @Override
    public int aplicarRegla(int n) {
        return (n * n) + 1; // ejemplo difícil
    }
}