package co.edu.poli.modelo;

public class Usuario {

    private int id;
    private String nombre;
    private String correo;
    private String contrasena;

    // 🔥 CONSTRUCTOR VACÍO (importante para algunos casos)
    public Usuario() {
    }

    // 🔥 CONSTRUCTOR SIN ID (para registrar)
    public Usuario(String nombre, String correo, String contrasena) {
        this.nombre = nombre;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    // 🔥 CONSTRUCTOR COMPLETO
    public Usuario(int id, String nombre, String correo, String contrasena) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    // 🔥 GETTERS Y SETTERS

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
}