package co.edu.poli.modelo;

public class Nivel {

    protected int idNivel;
    protected String nombre;
    protected String regla;

    public Nivel() {
    }

    public Nivel(int idNivel, String nombre, String regla) {
        this.idNivel = idNivel;
        this.nombre = nombre;
        this.regla = regla;
    }

    public int getIdNivel() {
        return idNivel;
    }

    public void setIdNivel(int idNivel) {
        this.idNivel = idNivel;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRegla() {
        return regla;
    }

    public void setRegla(String regla) {
        this.regla = regla;
    }

    public String obtenerRegla() {
        return regla;
    }

    public int aplicarRegla(int n) {
        return n;
    }
}
