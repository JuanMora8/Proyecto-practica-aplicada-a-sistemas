package co.edu.poli.modelo;

import java.time.LocalDate;
import co.edu.poli.modelo.Nivel;

public class Partida {

    private int idPartida;
    private LocalDate fecha;
    private String regla;
    private boolean validacion;
    private Nivel nivel;

    public Partida() {
    }

    public Partida(int idPartida, LocalDate fecha, String regla, boolean validacion, Nivel nivel) {
        this.idPartida = idPartida;
        this.fecha = fecha;
        this.regla = regla;
        this.validacion = validacion;
        this.nivel = nivel;
    }

    public int getIdPartida() {
        return idPartida;
    }

    public void setIdPartida(int idPartida) {
        this.idPartida = idPartida;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getRegla() {
        return regla;
    }

    public void setRegla(String regla) {
        this.regla = regla;
    }

    public boolean isValidacion() {
        return validacion;
    }

    public void setValidacion(boolean validacion) {
        this.validacion = validacion;
    }

    public Nivel getNivel() {
        return nivel;
    }

    public void setNivel(Nivel nivel) {
        this.nivel = nivel;
    }

    // Métodos UML
    public int calcular() {
        return 0;
    }

    public int aplicarRegla(int numero) {
        return nivel.aplicarRegla(numero);
    }

    public boolean adivinarRegla(String regla) {
        return this.regla.equalsIgnoreCase(regla);
    }
}