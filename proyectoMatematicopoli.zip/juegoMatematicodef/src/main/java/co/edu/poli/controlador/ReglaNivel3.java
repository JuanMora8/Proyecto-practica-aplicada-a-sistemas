/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.poli.controlador;

/**
 *
 * @author ASUS
 */
public class ReglaNivel3 {
    public int aplicarReglaNivelIntermedio(int n) {

    // 1 y 2. Validación
    if (n < 10) {
        throw new IllegalArgumentException("El número debe ser mayor o igual a 10");
    }

    // 3. Cálculo de la suma de los dígitos
    int suma = 0;
    int numero = n;

    while (numero > 0) {
        suma += numero % 10; // obtiene el último dígito
        numero = numero / 10; // elimina el último dígito
    }

    // 4. Aplicación de la regla
    int resultado = n - suma;

    // 5. Retorno
    return resultado;
}
    
    
    
    
}
