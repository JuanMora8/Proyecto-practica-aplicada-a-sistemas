/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.poli.controlador;

/**
 *
 * @author ASUS
 */
public class ReglaNivel1 {
    
public int aplicarReglaNivel1(int n) {

    if (n % 2 == 0) {
        return n - 2; // pares
        
        
    } else {
        return n - 1; // impares
    }
}
}
