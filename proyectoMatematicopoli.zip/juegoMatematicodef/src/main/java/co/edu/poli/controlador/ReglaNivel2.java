/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.poli.controlador;

/**
 *
 * @author ASUS
 */
public class ReglaNivel2 {
    
    public int aplicarReglaNivel2(int n) {

        // Validación básica
        if (n < 0) {
            throw new IllegalArgumentException("El número debe ser positivo");
        }

        // Obtener último dígito
        int ultimoDigito = n % 10;

        // Aplicar regla
        if (n % 5 == 0) {
            return n - 5;
        } else {
            return n - (2 * ultimoDigito);
        }
    }
    
    
}
