package co.edu.poli.controlador;

import java.io.IOException;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class NivelFacilController implements Initializable {

    @FXML
    private TextField txtNumero;

    @FXML
    private Label lblResultado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }

    // 🔥 BOTÓN
    @FXML
    private void calcular() {
        try {
            int numero = Integer.parseInt(txtNumero.getText());

            int resultado = aplicarReglaNivel1(numero);

            lblResultado.setText("Resultado: " + resultado);

        } catch (NumberFormatException e) {
            mostrarError("Debe ingresar un número entero válido");

        } catch (IllegalArgumentException e) {
            mostrarError(e.getMessage());
        }
    }

    // 🔥 LÓGICA DEL JUEGO (CORRECTA)
    public int aplicarReglaNivel1(int n) {

        if (n <= 0) {
            throw new IllegalArgumentException("Debe ingresar un número positivo mayor que 0");
        }

        if (n % 2 == 0) {
            return n - 2;
        } else {
            return n - 1;
        }
    }

    // 🔥 ALERTA
    private void mostrarError(String mensaje) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
    @FXML
private void volver(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Nivel.fxml"));
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    } catch (IOException e) {
        e.printStackTrace();
    }
}
@FXML
private void adivinarRegla(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(
            getClass().getResource("/com/mycompany/elefante/AdivinarRegla.fxml")
        );
        Parent root = loader.load();

        // 🔥 ENVIAR NIVEL
        AdivinarReglaController controller = loader.getController();
        controller.setNivel(1);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    } catch (IOException e) {
        e.printStackTrace();
    }
}
}