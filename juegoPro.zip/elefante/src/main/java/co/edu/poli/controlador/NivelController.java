package co.edu.poli.controlador;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;

public class NivelController implements Initializable {

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }

    @FXML
    private void irNivelFacil(MouseEvent event) {
        cambiarEscena("NivelFacil.fxml", event);
    }

    @FXML
    private void irNivelIntermedio(MouseEvent event) {
        cambiarEscena("NivelIntermedio.fxml", event);
    }

    @FXML
    private void irNivelDificil(MouseEvent event) {
        cambiarEscena("NivelDificil.fxml", event);
    }

    private void cambiarEscena(String archivoFXML, MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(archivoFXML));
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}