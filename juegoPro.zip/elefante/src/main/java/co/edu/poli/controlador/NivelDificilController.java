package co.edu.poli.controlador;

import java.io.IOException;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;

public class NivelDificilController implements Initializable {

    @FXML
    private TextField txtNumero;

    @FXML
    private Label lblResultado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }

    @FXML
    private void calcular() {
        try {
            int numero = Integer.parseInt(txtNumero.getText());

            int resultado = aplicarReglaNivel3(numero);

            lblResultado.setText("Resultado: " + resultado);

        } catch (NumberFormatException e) {
            mostrarError("Debe ingresar un número entero válido");

        } catch (IllegalArgumentException e) {
            mostrarError(e.getMessage());
        }
    }

    // 🔥 NIVEL DIFÍCIL (más compleja)
   public int aplicarReglaNivel3(int n) {

    // 1 y 2. Validación
    if (n < 10) {
        throw new IllegalArgumentException("El número debe ser mayor o igual a 10");
    }

    // 3. Cálculo de la suma de los dígitos
    int suma = 0;
    int numero = n;

    while (numero > 0) {
        suma += numero % 10; // obtiene el último dígito
        numero = numero / 10; // elimina el último dígito
    }

    // 4. Aplicación de la regla
    int resultado = n - suma;

    // 5. Retorno
    return resultado;
}
    

    private void mostrarError(String mensaje) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
     @FXML
    private void volver(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Nivel.fxml"));
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    } catch (IOException e) {
        e.printStackTrace();
    }
}
@FXML
private void adivinarRegla(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(
            getClass().getResource("/com/mycompany/elefante/AdivinarRegla.fxml")
        );

        Parent root = loader.load();

        // 🔥 AQUÍ ESTÁ LA CLAVE
        AdivinarReglaController controller = loader.getController();
        controller.setNivel(3); // 👈 NIVEL INTERMEDIO

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    } catch (IOException e) {
        e.printStackTrace();
    }
}
   
    }
