package co.edu.poli.controlador;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.Node;
import javafx.stage.Stage;

import java.io.IOException;
import co.edu.poli.modelo.Usuario;

public class RegistroController {

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtCorreo;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private Label lblMensaje;

  @FXML
private void registrar(ActionEvent event) {

    String nombre = txtNombre.getText();
    String correo = txtCorreo.getText();
    String password = txtPassword.getText();

    // 🔥 VALIDACIONES
    if (nombre.isEmpty() || correo.isEmpty() || password.isEmpty()) {
        lblMensaje.setText("Todos los campos son obligatorios");
        return;
    }

    if (!correo.contains("@")) {
        lblMensaje.setText("Correo inválido");
        return;
    }

    if (password.length() < 4) {
        lblMensaje.setText("La contraseña debe tener mínimo 4 caracteres");
        return;
    }

    // 🔥 AQUÍ ESTÁ LO IMPORTANTE
    Usuario usuario = new Usuario(nombre, correo, password);
    UsuarioDAO dao = new UsuarioDAO();

    boolean guardado = dao.registrarUsuario(usuario);

    if (guardado) {
        lblMensaje.setText("✅ Registro exitoso");
        limpiarCampos();
    } else {
        lblMensaje.setText("❌ Error al guardar (correo duplicado o BD)");
    }
}

    private void limpiarCampos() {
        txtNombre.clear();
        txtCorreo.clear();
        txtPassword.clear();
    }

    // 🔥 VOLVER (puedes cambiar a login o menú)
    @FXML
    private void volver(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/com/mycompany/elefante/Login.fxml")
            );

            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
