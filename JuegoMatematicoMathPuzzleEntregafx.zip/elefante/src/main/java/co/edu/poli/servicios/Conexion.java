package co.edu.poli.servicios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase encargada de gestionar la conexión
 * con la base de datos MySQL.
 * <p>
 * Esta clase utiliza JDBC para establecer
 * la conexión con la base de datos del sistema
 * "math_puzzle".
 * </p>
 * 
 * <p>
 * También carga el driver de MySQL y maneja
 * posibles errores relacionados con la conexión.
 * </p>
 * 
 * @author Kevin
 * @version 1.0
 */
public class Conexion {

    /**
     * URL de conexión a la base de datos.
     */
    private static final String URL =
        "jdbc:mysql://localhost:3306/math_puzzle?useSSL=false&serverTimezone=UTC";

    /**
     * Usuario de acceso a MySQL.
     */
    private static final String USER = "root";

    /**
     * Contraseña de acceso a MySQL.
     */
    private static final String PASSWORD = "kevin123";

    /**
     * Establece y retorna una conexión
     * con la base de datos.
     * <p>
     * El método carga el driver de MySQL
     * y posteriormente intenta conectarse
     * usando las credenciales configuradas.
     * </p>
     * 
     * @return objeto {@link Connection} si la conexión
     * es exitosa, o {@code null} en caso de error
     */
    public static Connection getConexion() {

        Connection con = null;

        try {

            // Carga el driver JDBC de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establece la conexión con la base de datos
            con = DriverManager.getConnection(URL, USER, PASSWORD);

        } catch (ClassNotFoundException e) {

            System.out.println("❌ Driver MySQL no encontrado");

        } catch (SQLException e) {

            System.out.println("❌ Error de conexión: " + e.getMessage());
        }

        return con;
    }
}