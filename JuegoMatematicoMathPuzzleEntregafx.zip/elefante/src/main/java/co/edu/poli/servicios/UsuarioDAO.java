package co.edu.poli.servicios;

import co.edu.poli.servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import co.edu.poli.modelo.Usuario;

/**
 * Clase encargada de gestionar las operaciones
 * relacionadas con los usuarios en la base de datos.
 * <p>
 * Esta clase implementa métodos para registrar
 * usuarios y validar el inicio de sesión
 * mediante consultas SQL usando JDBC.
 * </p>
 * 
 * @author Kevin
 * @version 1.0
 */
public class UsuarioDAO {

    // =========================
    // REGISTRAR USUARIO
    // =========================

    /**
     * Registra un nuevo usuario en la base de datos.
     * <p>
     * El método inserta el nombre, correo y contraseña
     * del usuario en la tabla {@code usuario}.
     * </p>
     * 
     * @param usuario objeto usuario con la información
     * a registrar
     * 
     * @return true si el registro fue exitoso,
     * false en caso contrario
     */
    public boolean registrarUsuario(Usuario usuario) {

        String sql = "INSERT INTO usuario (nombre, correo, contrasena) VALUES (?, ?, ?)";

        Connection con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ No hay conexión a la base de datos");
            return false;
        }

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getContrasena());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                System.out.println("✅ Usuario registrado correctamente");
                return true;
            }

        } catch (SQLException e) {

            System.out.println("❌ Error al registrar usuario:");
            e.printStackTrace();

        } finally {

            try {
                con.close();

            } catch (SQLException e) {

                System.out.println("❌ Error cerrando conexión");
            }
        }

        return false;
    }

    // =========================
    // LOGIN USUARIO
    // =========================

    /**
     * Verifica las credenciales de un usuario
     * para iniciar sesión.
     * <p>
     * El método consulta la base de datos buscando
     * coincidencia entre el correo y la contraseña.
     * </p>
     * 
     * @param correo correo electrónico ingresado
     * @param contrasena contraseña ingresada
     * 
     * @return objeto {@link Usuario} si el login
     * es exitoso, o {@code null} si las credenciales
     * son incorrectas
     */
    public Usuario login(String correo, String contrasena) {

        String sql = "SELECT * FROM usuario WHERE correo = ? AND contrasena = ?";

        Connection con = Conexion.getConexion();

        if (con == null) {

            System.out.println("❌ No hay conexión a la base de datos");
            return null;
        }

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, correo);
            ps.setString(2, contrasena);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                System.out.println("✅ Login exitoso");

                return new Usuario(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("correo"),
                        rs.getString("contrasena")
                );
            }

        } catch (SQLException e) {

            System.out.println("❌ Error en login:");
            e.printStackTrace();

        } finally {

            try {
                con.close();

            } catch (SQLException e) {

                System.out.println("❌ Error cerrando conexión");
            }
        }

        System.out.println("❌ Usuario no encontrado");
        return null;
    }
}