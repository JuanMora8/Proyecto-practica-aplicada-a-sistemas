package co.edu.poli.modelo;

import java.time.LocalDate;

/**
 * Clase que representa una partida dentro del juego.
 * <p>
 * Una partida contiene información relacionada con
 * el identificador de la partida, la fecha de creación,
 * el nivel actual y el puntaje total acumulado por el jugador.
 * </p>
 * 
 * <p>
 * Además, esta clase permite aplicar reglas asociadas
 * al nivel seleccionado y verificar si el jugador
 * adivinó correctamente la regla del juego.
 * </p>
 * 
 * @author Kevin
 * @version 1.0
 */
public class Partida {

    /**
     * Identificador único de la partida.
     */
    private int idPartida;

    /**
     * Fecha de creación de la partida.
     */
    private LocalDate fecha;

    /**
     * Nivel actual de la partida.
     */
    private Nivel nivel;

    /**
     * Puntaje total acumulado.
     */
    private int puntajeTotal;

    /**
     * Constructor vacío.
     * <p>
     * Inicializa la fecha actual y el puntaje en cero.
     * </p>
     */
    public Partida() {

        this.fecha = LocalDate.now();
        this.puntajeTotal = 0;
    }

    /**
     * Constructor con parámetros.
     * 
     * @param idPartida identificador de la partida
     * @param nivel nivel asociado a la partida
     */
    public Partida(int idPartida, Nivel nivel) {

        this.idPartida = idPartida;
        this.nivel = nivel;
        this.fecha = LocalDate.now();
        this.puntajeTotal = 0;
    }

    // =========================================================
    // GETTERS Y SETTERS
    // =========================================================

    /**
     * Obtiene el identificador de la partida.
     * 
     * @return id de la partida
     */
    public int getIdPartida() {
        return idPartida;
    }

    /**
     * Modifica el identificador de la partida.
     * 
     * @param idPartida nuevo identificador
     */
    public void setIdPartida(int idPartida) {
        this.idPartida = idPartida;
    }

    /**
     * Obtiene la fecha de la partida.
     * 
     * @return fecha de la partida
     */
    public LocalDate getFecha() {
        return fecha;
    }

    /**
     * Modifica la fecha de la partida.
     * 
     * @param fecha nueva fecha
     */
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    /**
     * Obtiene el nivel actual de la partida.
     * 
     * @return nivel actual
     */
    public Nivel getNivel() {
        return nivel;
    }

    /**
     * Modifica el nivel de la partida.
     * 
     * @param nivel nuevo nivel
     */
    public void setNivel(Nivel nivel) {
        this.nivel = nivel;
    }

    /**
     * Obtiene el puntaje total acumulado.
     * 
     * @return puntaje total
     */
    public int getPuntajeTotal() {
        return puntajeTotal;
    }

    /**
     * Modifica el puntaje total.
     * 
     * @param puntajeTotal nuevo puntaje total
     */
    public void setPuntajeTotal(int puntajeTotal) {
        this.puntajeTotal = puntajeTotal;
    }

    // =========================================================
    // SISTEMA DE PUNTOS
    // =========================================================

    /**
     * Suma puntos al puntaje total de la partida.
     * 
     * @param puntos cantidad de puntos a agregar
     */
    public void sumarPuntos(int puntos) {
        puntajeTotal += puntos;
    }

    /**
     * Reinicia el puntaje total de la partida.
     */
    public void reiniciarPuntaje() {
        puntajeTotal = 0;
    }

    // =========================================================
    // LÓGICA DEL JUEGO
    // =========================================================

    /**
     * Aplica la regla matemática del nivel actual
     * a un número ingresado.
     * 
     * @param numero número de entrada
     * @return resultado de aplicar la regla
     * 
     * @throws IllegalStateException si no existe un nivel asignado
     */
    public int aplicarRegla(int numero) {

        if (nivel == null) {
            throw new IllegalStateException(
                "No hay nivel asignado a la partida"
            );
        }

        return nivel.aplicarRegla(numero);
    }

    /**
     * Verifica si la regla ingresada por el jugador
     * coincide con la regla del nivel actual.
     * 
     * @param reglaIngresada regla escrita por el jugador
     * @return true si la regla es correcta,
     * false en caso contrario
     */
    public boolean adivinarRegla(String reglaIngresada) {

        if (nivel == null) {
            return false;
        }

        return nivel.getRegla()
                .equalsIgnoreCase(reglaIngresada);
    }
}