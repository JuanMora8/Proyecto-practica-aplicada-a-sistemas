package co.edu.poli.modelo;

/**
 * Clase que representa una pregunta del tipo
 * "Adivinar la Regla" dentro del juego.
 * <p>
 * La clase almacena una descripción de la regla,
 * un conjunto de opciones posibles y el índice
 * correspondiente a la respuesta correcta.
 * </p>
 * 
 * @author Kevin
 * @version 1.0
 */
public class AdivinarRegla2 {

    /**
     * Descripción o enunciado de la pregunta.
     */
    private String descripcion;

    /**
     * Arreglo que almacena las opciones de respuesta.
     */
    private String[] opciones = new String[3];

    /**
     * Índice de la opción correcta.
     */
    private int indiceCorrecto;

    /**
     * Constructor vacío de la clase.
     */
    public AdivinarRegla2() {
    }

    /**
     * Constructor con parámetros.
     * 
     * @param descripcion descripción de la pregunta
     * @param opciones arreglo de opciones de respuesta
     * @param indiceCorrecto índice de la respuesta correcta
     */
    public AdivinarRegla2(String descripcion, String[] opciones, int indiceCorrecto) {
        this.descripcion = descripcion;
        this.opciones = opciones;
        this.indiceCorrecto = indiceCorrecto;
    }

    /**
     * Obtiene la descripción de la pregunta.
     * 
     * @return descripción de la pregunta
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Modifica la descripción de la pregunta.
     * 
     * @param descripcion nueva descripción
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el arreglo de opciones.
     * 
     * @return opciones de respuesta
     */
    public String[] getOpciones() {
        return opciones;
    }

    /**
     * Modifica las opciones de respuesta.
     * 
     * @param opciones nuevo arreglo de opciones
     */
    public void setOpciones(String[] opciones) {
        this.opciones = opciones;
    }

    /**
     * Obtiene el índice de la respuesta correcta.
     * 
     * @return índice correcto
     */
    public int getIndiceCorrecto() {
        return indiceCorrecto;
    }

    /**
     * Modifica el índice de la respuesta correcta.
     * 
     * @param indiceCorrecto nuevo índice correcto
     */
    public void setIndiceCorrecto(int indiceCorrecto) {
        this.indiceCorrecto = indiceCorrecto;
    }

    /**
     * Selecciona una opción como correcta.
     * 
     * @param indice índice de la opción seleccionada
     */
    public void seleccionarOpcion(int indice) {
        this.indiceCorrecto = indice;
    }

    /**
     * Verifica si la respuesta seleccionada es correcta.
     * <p>
     * El método retorna verdadero cuando el índice
     * correcto corresponde a la posición 1.
     * </p>
     * 
     * @return true si la respuesta es correcta,
     * false en caso contrario
     */
    public boolean esCorrecto() {
        return indiceCorrecto == 1;
    }
}