package co.edu.poli.modelo;

/**
 * Clase que representa un nivel de dificultad alta
 * dentro del juego.
 * <p>
 * Esta clase hereda de {@link Nivel} e implementa
 * una regla matemática específica para los desafíos
 * del nivel difícil.
 * </p>
 * 
 * <p>
 * La regla aplicada en este nivel corresponde a:
 * </p>
 * 
 * 
::contentReference[oaicite:0]{index=0}

 * 
 * @author Kevin
 * @version 1.0
 */
public class NivelDificil extends Nivel {

    /**
     * Constructor vacío.
     */
    public NivelDificil() {
        super();
    }

    /**
     * Constructor con parámetros.
     * 
     * @param idNivel identificador del nivel
     * @param nombre nombre del nivel
     * @param regla descripción de la regla
     */
    public NivelDificil(int idNivel, String nombre, String regla) {
        super(idNivel, nombre, regla);
    }

    /**
     * Verifica si la regla difícil se cumple.
     * <p>
     * Actualmente retorna siempre {@code true}
     * como ejemplo de validación.
     * </p>
     * 
     * @return true si la regla es válida
     */
    public boolean verificarReglaDificil() {
        return true;
    }

    /**
     * Aplica la regla matemática del nivel difícil.
     * <p>
     * La operación realizada es:
     * </p>
     * 
     * 
::contentReference[oaicite:1]{index=1}

     * 
     * @param n número de entrada
     * @return resultado de aplicar la regla
     */
    @Override
    public int aplicarRegla(int n) {
        return (n * n) + 1; // ejemplo difícil
    }
}