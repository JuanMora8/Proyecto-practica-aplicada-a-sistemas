package co.edu.poli.controlador;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.stage.Stage;

public class InstruccionesController {

    @FXML
    private void cerrar(ActionEvent event) {
        // Obtiene la ventana actual (popup)
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        
        // La cierra
        stage.close();
    }
}