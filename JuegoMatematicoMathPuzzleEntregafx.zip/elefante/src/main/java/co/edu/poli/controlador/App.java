package co.edu.poli.controlador;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("Login"), 520, 330);
        
        stage.setScene(scene);
        stage.setResizable(false); // 👈 BLOQUEA EL REDIMENSIONAMIENTO
        stage.show();
        
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

 private static Parent loadFXML(String fxml) throws IOException {

    FXMLLoader fxmlLoader =
        new FXMLLoader(App.class.getResource("/co/edu/poli/vista/" + fxml + ".fxml"));

    return fxmlLoader.load();
}


    public static void main(String[] args) {
        launch();
        System.out.println(App.class.getResource("Login.fxml"));
    }

}