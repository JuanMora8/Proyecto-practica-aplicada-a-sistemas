package co.edu.poli.modelo;

/**
 * Clase que representa un nivel de dificultad intermedia
 * dentro del juego.
 * <p>
 * Esta clase hereda de {@link Nivel} e implementa
 * una regla matemática de complejidad media para
 * los desafíos del nivel intermedio.
 * </p>
 * 
 * <p>
 * La regla aplicada en este nivel corresponde a:
 * </p>
 * 
 * 
::contentReference[oaicite:0]{index=0}

 * 
 * @author Kevin
 * @version 1.0
 */
public class NivelIntermedio extends Nivel {

    /**
     * Constructor vacío.
     */
    public NivelIntermedio() {
        super();
    }

    /**
     * Constructor con parámetros.
     * 
     * @param idNivel identificador del nivel
     * @param nombre nombre del nivel
     * @param regla descripción de la regla
     */
    public NivelIntermedio(int idNivel, String nombre, String regla) {
        super(idNivel, nombre, regla);
    }

    /**
     * Verifica si la regla intermedia se cumple.
     * <p>
     * Actualmente retorna siempre {@code true}
     * como ejemplo de validación.
     * </p>
     * 
     * @return true si la regla es válida
     */
    public boolean verificarReglaIntermedia() {
        return true;
    }

    /**
     * Aplica la regla matemática del nivel intermedio.
     * <p>
     * La operación realizada es:
     * </p>
     * 
     * 
::contentReference[oaicite:1]{index=1}

     * 
     * @param n número de entrada
     * @return resultado de aplicar la regla
     */
    @Override
    public int aplicarRegla(int n) {
        return n * 2; // ejemplo intermedio
    }
}