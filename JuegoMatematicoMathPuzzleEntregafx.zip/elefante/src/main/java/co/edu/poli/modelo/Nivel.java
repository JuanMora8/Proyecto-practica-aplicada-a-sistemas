package co.edu.poli.modelo;

/**
 * Clase abstracta que representa un nivel dentro del juego.
 * <p>
 * Cada nivel posee un identificador, un nombre y una regla
 * matemática o lógica que será aplicada durante la partida.
 * Además, la clase controla el sistema de intentos y el
 * cálculo del puntaje obtenido por el jugador.
 * </p>
 * 
 * <p>
 * Las clases hijas deben implementar el método
 * {@code aplicarRegla(int n)} para definir el comportamiento
 * específico de cada nivel.
 * </p>
 * 
 * @author Kevin
 * @version 1.0
 */
public abstract class Nivel {

    /**
     * Identificador único del nivel.
     */
    private int idNivel;

    /**
     * Nombre del nivel.
     */
    private String nombre;

    /**
     * Regla asociada al nivel.
     */
    private String regla;

    /**
     * Número de intentos realizados por el jugador.
     */
    protected int intentos;

    /**
     * Número máximo de intentos permitidos.
     */
    protected final int MAX_INTENTOS = 5;

    /**
     * Constructor vacío.
     * <p>
     * Inicializa los intentos en cero.
     * </p>
     */
    public Nivel() {
        this.intentos = 0;
    }

    /**
     * Constructor con parámetros.
     * 
     * @param idNivel identificador del nivel
     * @param nombre nombre del nivel
     * @param regla regla asociada al nivel
     */
    public Nivel(int idNivel, String nombre, String regla) {

        this.idNivel = idNivel;
        this.nombre = nombre;
        this.regla = regla;
        this.intentos = 0;
    }

    // =========================================================
    // GETTERS Y SETTERS
    // =========================================================

    /**
     * Obtiene el identificador del nivel.
     * 
     * @return id del nivel
     */
    public int getIdNivel() {
        return idNivel;
    }

    /**
     * Modifica el identificador del nivel.
     * 
     * @param idNivel nuevo identificador
     */
    public void setIdNivel(int idNivel) {
        this.idNivel = idNivel;
    }

    /**
     * Obtiene el nombre del nivel.
     * 
     * @return nombre del nivel
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Modifica el nombre del nivel.
     * 
     * @param nombre nuevo nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la regla del nivel.
     * 
     * @return regla del nivel
     */
    public String getRegla() {
        return regla;
    }

    /**
     * Modifica la regla del nivel.
     * 
     * @param regla nueva regla
     */
    public void setRegla(String regla) {
        this.regla = regla;
    }

    /**
     * Obtiene la cantidad de intentos realizados.
     * 
     * @return número de intentos
     */
    public int getIntentos() {
        return intentos;
    }

    /**
     * Obtiene el número máximo de intentos permitidos.
     * 
     * @return máximo de intentos
     */
    public int getMaxIntentos() {
        return MAX_INTENTOS;
    }

    // =========================================================
    // CONTROL DE INTENTOS
    // =========================================================

    /**
     * Incrementa en uno la cantidad de intentos realizados.
     */
    public void consumirIntento() {
        intentos++;
    }

    /**
     * Calcula los intentos restantes disponibles.
     * 
     * @return cantidad de intentos restantes
     */
    public int getIntentosRestantes() {
        return MAX_INTENTOS - intentos;
    }

    /**
     * Verifica si el jugador ya no tiene intentos disponibles.
     * 
     * @return true si no quedan intentos,
     * false en caso contrario
     */
    public boolean sinIntentos() {
        return intentos >= MAX_INTENTOS;
    }

    /**
     * Reinicia el contador de intentos.
     */
    public void reiniciarIntentos() {
        intentos = 0;
    }

    // =========================================================
    // SISTEMA DE PUNTOS
    // =========================================================

    /**
     * Calcula el puntaje obtenido según
     * la cantidad de intentos utilizados.
     * 
     * <ul>
     * <li>1 intento = 10 puntos</li>
     * <li>2 intentos = 5 puntos</li>
     * <li>3 intentos = 2 puntos</li>
     * <li>Más de 3 intentos = 0 puntos</li>
     * </ul>
     * 
     * @return puntaje calculado
     */
    public int calcularPuntaje() {

        switch (intentos) {

            case 1:
                return 10;

            case 2:
                return 5;

            case 3:
                return 2;

            default:
                return 0;
        }
    }

    // =========================================================
    // MÉTODO ABSTRACTO
    // =========================================================

    /**
     * Aplica la regla específica del nivel
     * a un número recibido como parámetro.
     * <p>
     * Este método debe ser implementado
     * por las clases hijas.
     * </p>
     * 
     * @param n número de entrada
     * @return resultado de aplicar la regla
     */
    public abstract int aplicarRegla(int n);
}