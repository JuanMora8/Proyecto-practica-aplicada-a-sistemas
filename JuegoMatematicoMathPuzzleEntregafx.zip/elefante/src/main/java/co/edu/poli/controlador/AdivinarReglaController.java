package co.edu.poli.controlador;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class AdivinarReglaController implements Initializable {

    @FXML
    private Label lblDescripcion;

    @FXML
    private Button btnOpcionA;

    @FXML
    private Button btnOpcionB;

    @FXML
    private Button btnOpcionC;

    @FXML
    private Label lblResultado;

    private int nivel;
    private String respuestaCorrecta = "";
    private String seleccion = "";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    // 🔥 RECIBE EL NIVEL
    public void setNivel(int nivel) {
        this.nivel = nivel;
        configurarNivel();
    }

    // 🔥 CONFIGURA SEGÚN NIVEL
    private void configurarNivel() {

        switch (nivel) {

            case 1:
                lblDescripcion.setText("¿Cuál es la regla?");
                btnOpcionA.setText("Si es par resta 2, si es impar resta 1");
                btnOpcionB.setText("Multiplica por 2");
                btnOpcionC.setText("Suma 10");
                respuestaCorrecta = "A";
                break;

            case 2:
                lblDescripcion.setText("¿Cuál es la regla?");
                btnOpcionA.setText("Si es múltiplo de 5 resta 5");
                btnOpcionB.setText("Resta el doble del último dígito");
                btnOpcionC.setText("Suma 3");
                respuestaCorrecta = "B";
                break;

            case 3:
                lblDescripcion.setText("¿Cuál es la regla?");
                btnOpcionA.setText("Multiplica por la suma de sus dígitos y resta 3");
                btnOpcionB.setText("Divide entre 2");
                btnOpcionC.setText("Suma 100");
                respuestaCorrecta = "A";
                break;
        }
    }

    // 🔥 ESTILOS
    private String estiloNormal() {
        return "-fx-background-color: #1e1e3f;" +
               "-fx-text-fill: white;" +
               "-fx-border-color: #8A7CFF;" +
               "-fx-background-radius: 10;" +
               "-fx-border-radius: 10;" +
               "-fx-cursor: hand;";
    }

    private String estiloSeleccionado() {
        return "-fx-background-color: #8A7CFF;" +
               "-fx-text-fill: white;" +
               "-fx-border-color: white;" +
               "-fx-background-radius: 10;" +
               "-fx-border-radius: 10;" +
               "-fx-cursor: hand;";
    }

    // 🔥 RESALTAR SELECCIÓN
    private void resaltarSeleccion(Button botonSeleccionado) {

        btnOpcionA.setStyle(estiloNormal());
        btnOpcionB.setStyle(estiloNormal());
        btnOpcionC.setStyle(estiloNormal());

        botonSeleccionado.setStyle(estiloSeleccionado());
    }

    // 🔥 SELECCIÓN
    @FXML
    private void seleccionarA(ActionEvent event) {
        seleccion = "A";
        resaltarSeleccion(btnOpcionA);
    }

    @FXML
    private void seleccionarB(ActionEvent event) {
        seleccion = "B";
        resaltarSeleccion(btnOpcionB);
    }

    @FXML
    private void seleccionarC(ActionEvent event) {
        seleccion = "C";
        resaltarSeleccion(btnOpcionC);
    }

    // 🔥 VALIDAR RESPUESTA
    @FXML
    private void confirmar(ActionEvent event) {
        if (seleccion.equals("")) {
            lblResultado.setText("Selecciona una opción");
            return;
        }

        if (seleccion.equals(respuestaCorrecta)) {
            lblResultado.setText("✅ Correcto");
        } else {
            lblResultado.setText("❌ Incorrecto");
        }
    }

    // 🔥 VOLVER
    @FXML
    private void volver(ActionEvent event) {
        try {
            String archivo = "";

            switch (nivel) {
                case 1:
                    archivo = "/co/edu/poli/vista/NivelFacil.fxml";
                    break;
                case 2:
                    archivo = "/co/edu/poli/vista/NivelIntermedio.fxml";
                    break;
                case 3:
                    archivo = "/co/edu/poli/vista/NivelDificil.fxml";
                    break;
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(archivo));
            Parent root = loader.load();

            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}