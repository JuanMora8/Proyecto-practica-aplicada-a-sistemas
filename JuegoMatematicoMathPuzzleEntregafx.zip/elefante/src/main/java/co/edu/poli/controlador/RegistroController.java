package co.edu.poli.controlador;

import co.edu.poli.servicios.UsuarioDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.Node;
import javafx.stage.Stage;

import java.io.IOException;

import co.edu.poli.modelo.Usuario;

public class RegistroController {

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtCorreo;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private Label lblMensaje;

    // 🔥 INICIALIZACIÓN (VALIDACIÓN EN TIEMPO REAL)
    @FXML
    public void initialize() {
        txtCorreo.textProperty().addListener((obs, oldText, newText) -> {
            if (newText.isEmpty()) {
                txtCorreo.setStyle("");
            } else if (!validarCorreo(newText)) {
                txtCorreo.setStyle("-fx-border-color: red;");
            } else {
                txtCorreo.setStyle("-fx-border-color: green;");
            }
        });
    }

    @FXML
    private void registrar(ActionEvent event) {

        String nombre = txtNombre.getText();
        String correo = txtCorreo.getText();
        String password = txtPassword.getText();

        // 🔥 VALIDACIONES
        if (nombre.isEmpty() || correo.isEmpty() || password.isEmpty()) {
            lblMensaje.setText("Todos los campos son obligatorios");
            mostrarAlerta("Todos los campos son obligatorios");
            return;
        }

        if (!validarCorreo(correo)) {
            lblMensaje.setText("Correo inválido");
            mostrarAlerta("Formato correcto: usuario@gmail.com");
            return;
        }

        if (password.length() < 4) {
            lblMensaje.setText("La contraseña debe tener mínimo 4 caracteres");
            mostrarAlerta("La contraseña debe tener mínimo 4 caracteres");
            return;
        }

        // 🔥 CREAR USUARIO
        Usuario usuario = new Usuario(nombre, correo, password);
        UsuarioDAO dao = new UsuarioDAO();

        boolean guardado = dao.registrarUsuario(usuario);

        if (guardado) {
            lblMensaje.setText("✅ Registro exitoso");
            mostrarAlerta("Usuario registrado correctamente");
            limpiarCampos();
        } else {
            lblMensaje.setText("❌ Error al guardar");
            mostrarAlerta("El correo ya existe o hubo un error en la base de datos");
        }
    }

   private boolean validarCorreo(String correo) {
    String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$";
    return correo.matches(regex);
}

    // 🔥 ALERTAS
    private void mostrarAlerta(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validación");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    // 🔥 LIMPIAR CAMPOS
    private void limpiarCampos() {
        txtNombre.clear();
        txtCorreo.clear();
        txtPassword.clear();
        txtCorreo.setStyle(""); // reset borde
    }

    // 🔥 VOLVER
    @FXML
    private void volver(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/co/edu/poli/vista/Login.fxml")
            );

            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
