package co.edu.poli.modelo;

/**
 * Clase que representa un usuario dentro del sistema.
 * <p>
 * La clase almacena la información básica de un usuario,
 * incluyendo su identificador, nombre, correo electrónico
 * y contraseña.
 * </p>
 * 
 * <p>
 * Se utiliza para gestionar el registro y acceso
 * de los jugadores en la aplicación.
 * </p>
 * 
 * @author Kevin
 * @version 1.0
 */
public class Usuario {

    /**
     * Identificador único del usuario.
     */
    private int id;

    /**
     * Nombre del usuario.
     */
    private String nombre;

    /**
     * Correo electrónico del usuario.
     */
    private String correo;

    /**
     * Contraseña del usuario.
     */
    private String contrasena;

    /**
     * Constructor vacío.
     * <p>
     * Necesario para ciertos procesos de creación
     * de objetos y serialización.
     * </p>
     */
    public Usuario() {
    }

    /**
     * Constructor sin identificador.
     * <p>
     * Se utiliza principalmente para el registro
     * de nuevos usuarios.
     * </p>
     * 
     * @param nombre nombre del usuario
     * @param correo correo electrónico del usuario
     * @param contrasena contraseña del usuario
     */
    public Usuario(String nombre, String correo, String contrasena) {
        this.nombre = nombre;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    /**
     * Constructor completo.
     * 
     * @param id identificador del usuario
     * @param nombre nombre del usuario
     * @param correo correo electrónico del usuario
     * @param contrasena contraseña del usuario
     */
    public Usuario(int id, String nombre, String correo, String contrasena) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    // =========================================================
    // GETTERS Y SETTERS
    // =========================================================

    /**
     * Obtiene el identificador del usuario.
     * 
     * @return id del usuario
     */
    public int getId() {
        return id;
    }

    /**
     * Modifica el identificador del usuario.
     * 
     * @param id nuevo identificador
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre del usuario.
     * 
     * @return nombre del usuario
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Modifica el nombre del usuario.
     * 
     * @param nombre nuevo nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el correo electrónico del usuario.
     * 
     * @return correo electrónico
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Modifica el correo electrónico del usuario.
     * 
     * @param correo nuevo correo electrónico
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * Obtiene la contraseña del usuario.
     * 
     * @return contraseña del usuario
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Modifica la contraseña del usuario.
     * 
     * @param contrasena nueva contraseña
     */
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
}