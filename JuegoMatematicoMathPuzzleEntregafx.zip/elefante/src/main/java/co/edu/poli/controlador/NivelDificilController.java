package co.edu.poli.controlador;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import co.edu.poli.modelo.NivelDificil;
import co.edu.poli.modelo.Partida;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import javafx.stage.Stage;

public class NivelDificilController implements Initializable {

    // =========================================================
    // 🔥 COMPONENTES FXML
    // =========================================================

    @FXML
    private TextField txtNumero;

    @FXML
    private Label lblResultado;

    @FXML
    private Label lblIntentos;

    @FXML
    private Label lblPuntaje;

    // =========================================================
    // 🔥 INSTANCIAS DEL MODELO
    // =========================================================

    private NivelDificil nivel;
    private Partida partida;

    // =========================================================
    // 🔥 INITIALIZE
    // =========================================================

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // 🔥 CREAR NIVEL
        nivel = new NivelDificil();

        // 🔥 CREAR PARTIDA
        partida = new Partida();

        // 🔥 ASIGNAR NIVEL A LA PARTIDA
        partida.setNivel(nivel);

        // 🔥 LABELS INICIALES
        lblIntentos.setText(
            "Intentos restantes: "
            + nivel.getIntentosRestantes()
        );

        lblPuntaje.setText(
            "Puntaje: "
            + partida.getPuntajeTotal()
        );
    }

    // =========================================================
    // 🔥 BOTÓN PROBAR
    // =========================================================

    @FXML
    private void calcular() {

        try {

            // 🔥 VALIDAR SI YA NO HAY INTENTOS
            if (nivel.sinIntentos()) {

                mostrarError(
                    "Game Over. Ya no tienes intentos."
                );

                return;
            }

            // 🔥 OBTENER NÚMERO
            int numero =
                Integer.parseInt(txtNumero.getText());

            // 🔥 CONSUMIR INTENTO
            nivel.consumirIntento();

            // 🔥 APLICAR REGLA
            int resultado =
                nivel.aplicarRegla(numero);

            // 🔥 MOSTRAR RESULTADO
            lblResultado.setText(
                "Resultado: " + resultado
            );

            // 🔥 ACTUALIZAR INTENTOS
            lblIntentos.setText(
                "Intentos restantes: "
                + nivel.getIntentosRestantes()
            );

            // 🔥 CALCULAR PUNTOS
            int puntos =
                nivel.calcularPuntaje();

            // 🔥 SUMAR PUNTOS
            partida.sumarPuntos(puntos);

            // 🔥 ACTUALIZAR LABEL PUNTAJE
            lblPuntaje.setText(
                "Puntaje: "
                + partida.getPuntajeTotal()
            );

            // 🔥 VERIFICAR GAME OVER
            if (nivel.sinIntentos()) {

                mostrarError(
                    "Has agotado todos los intentos"
                );
            }

        } catch (NumberFormatException e) {

            mostrarError(
                "Debe ingresar un número entero válido"
            );

        } catch (IllegalArgumentException e) {

            mostrarError(
                e.getMessage()
            );
        }
    }

    // =========================================================
    // 🔥 ALERTAS
    // =========================================================

    private void mostrarError(String mensaje) {

        Alert alert =
            new Alert(AlertType.ERROR);

        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);

        alert.showAndWait();
    }

    // =========================================================
    // 🔥 VOLVER
    // =========================================================

    @FXML
    private void volver(ActionEvent event) {

        try {

            FXMLLoader loader =
                new FXMLLoader(
                    getClass().getResource(
                        "/co/edu/poli/vista/Nivel.fxml"
                    )
                );

            Parent root = loader.load();

            Stage stage =
                (Stage) ((Node) event.getSource())
                .getScene()
                .getWindow();

            stage.setScene(new Scene(root));

            stage.show();

        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    // =========================================================
    // 🔥 ADIVINAR REGLA
    // =========================================================

    @FXML
    private void adivinarRegla(ActionEvent event) {

        try {

            FXMLLoader loader =
                new FXMLLoader(
                    getClass().getResource(
                        "/co/edu/poli/vista/AdivinarRegla.fxml"
                    )
                );

            Parent root = loader.load();

            // 🔥 OBTENER CONTROLLER
            AdivinarReglaController controller =
                loader.getController();

            // 🔥 ENVIAR NIVEL
            controller.setNivel(3);

            // 🔥 CAMBIAR ESCENA
            Stage stage =
                (Stage) ((Node) event.getSource())
                .getScene()
                .getWindow();

            Scene scene =
                ((Node) event.getSource())
                .getScene();

            scene.setRoot(root);

            stage.show();

        } catch (IOException e) {

            e.printStackTrace();
        }
    }
}